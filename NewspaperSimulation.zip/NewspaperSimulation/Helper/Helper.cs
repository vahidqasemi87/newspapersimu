﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewspaperSimulation.Helper
{
    public static class Helper
    {
        public static int[] Rows()
        {
            int[] numbers = new int[20];
            for (int i = 1; i <= 20; i++)
            {
                numbers[i - 1] = i;
            }
            return numbers;
        }
        public static int RandomTwo()
        {
            return new Random().Next(10, 99);
        }
        public static string GetDay(int number)
        {
            switch (number)
            {
                case int n when (n >= 1 && n <= 35):
                    return "خوب";
                case int n when (n >= 36 && n <= 80):
                    return "متوسط";
                case int n when (n >= 81 && n <= 100):
                    return "بد";
                default:
                    return "";
            }

        }
        public static int GetRequest(string situation, int number)
        {
            if (situation == "خوب")
            {
                switch (number)
                {
                    case int n when (n >= 1 && n <= 3):
                        return 40;
                    case int n when (n >= 4 && n <= 8):
                        return 50;
                    case int n when (n >=9 && n <= 23):
                        return 60;
                    case int n when (n >=24 && n <=42):
                        return 70;
                    case int n when (n >= 44 && n <= 78):
                        return 80;
                    case int n when (n >= 79 && n <= 93):
                        return 90;
                    case int n when (n >= 94 && n <= 100):
                        return 100;
                    default:
                        return 1;
                }
            }
            else if (situation == "متوسط")
            {
                switch (number)
                {
                    case int n when (n >= 0 && n <= 10):
                        return 40;
                    case int n when (n >= 11 && n <= 28):
                        return 50;
                    case int n when (n >= 29 && n <= 68):
                        return 60;
                    case int n when (n >= 69 && n <= 88):
                        return 70;
                    case int n when (n >= 89 && n <= 96):
                        return 80;
                    case int n when (n >= 97 && n <= 100):
                        return 90;
                    default:
                        return 1;
                }
            }
            else
            {
                switch (number)
                {
                    case int n when (n >= 01 && n <= 44):
                        return 40;
                    case int n when (n >= 45 && n <= 66):
                        return 50;
                    case int n when (n >= 67 && n <= 82):
                        return 60;
                    case int n when (n >= 83 && n <= 94):
                        return 70;
                    case int n when (n >= 95 && n <= 100):
                        return 80;
                    default:
                        return 1;
                }
            }
            

        }

    }
}
